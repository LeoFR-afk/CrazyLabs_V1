extends Control
## Menu principal improvisado: JUGAR (empieza en el primer nivel) y SALIR.
## Es la escena principal del proyecto (Project Settings > Application > Run > Main Scene).

const Estilo = preload("res://menu/estilo_menu.gd")

## Primer nivel del juego
@export_file("*.tscn") var primer_nivel: String = "res://tutorial/Tutorial.tscn"
## Segundos que tarda el fundido a negro al darle a Jugar
@export var duracion_fundido: float = 0.6

var _titulo: Label
var _fundido: ColorRect
var _btn_jugar: Button
var _cambiando: bool = false
var _tiempo: float = 0.0


func _ready() -> void:
	get_tree().paused = false # por si se llega aqui desde el menu de pausa
	_construir_ui()
	_btn_jugar.grab_focus()




func _construir_ui() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var fondo := TextureRect.new()
	fondo.texture = load("res://tutorial/Sprites/Escenarios/Escenario1_Finel.png")   # tu imagen
	fondo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	fondo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED  # llena la pantalla sin deformar
	fondo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fondo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(fondo)

	# Capa oscura opcional para que los textos se lean (0 = sin oscurecer)
	var velo := ColorRect.new()
	velo.color = Color(0, 0, 0, 0.35)
	velo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	velo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(velo)

	var centro := CenterContainer.new()
	centro.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(centro)

	var caja := VBoxContainer.new()
	caja.add_theme_constant_override("separation", 16)
	caja.alignment = BoxContainer.ALIGNMENT_CENTER
	centro.add_child(caja)

	_titulo = Estilo.crear_texto("CRAZYLABS", 96, Color.WHITE)
	caja.add_child(_titulo)


	var espacio := Control.new()
	espacio.custom_minimum_size = Vector2(0, 40)
	caja.add_child(espacio)

	_btn_jugar = Estilo.crear_boton("Jugar")
	_btn_jugar.pressed.connect(_jugar)
	caja.add_child(_btn_jugar)

	var btn_salir := Estilo.crear_boton("Salir")
	btn_salir.pressed.connect(func() -> void: get_tree().quit())
	caja.add_child(btn_salir)




	# Fundido a negro (arriba de todo) para entrar al juego
	_fundido = ColorRect.new()
	_fundido.color = Color(0, 0, 0, 0)
	_fundido.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_fundido.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_fundido)


func _jugar() -> void:
	if _cambiando:
		return
	_cambiando = true
	var t := create_tween()
	t.tween_property(_fundido, "color:a", 1.0, duracion_fundido)
	await t.finished
	get_tree().change_scene_to_file(primer_nivel)
