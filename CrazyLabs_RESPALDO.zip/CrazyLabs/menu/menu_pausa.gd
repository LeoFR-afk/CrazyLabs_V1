extends CanvasLayer
## Menu de pausa (tecla ESC): Reanudar, Reiniciar nivel y Menu principal.
##
## Cada nivel lo agrega por codigo AL FINAL de su _ready() (despues de crear los paneles), para que
## cuando hay un panel abierto el ESC se lo quede el panel (cierra el panel) y no pause el juego.
## El nivel le asigna "puede_pausar" para bloquear la pausa durante paneles, transiciones, etc.

const Estilo = preload("res://menu/estilo_menu.gd")
const ESCENA_MENU_PRINCIPAL := "res://menu/MenuPrincipal.tscn"

## Devuelve false cuando NO se debe poder pausar (lo asigna el nivel)
var puede_pausar: Callable = func() -> bool: return true

var _btn_reanudar: Button


func _ready() -> void:
	layer = 90 # arriba de los paneles (50) y de la interfaz del nivel (40)
	process_mode = Node.PROCESS_MODE_ALWAYS # sigue funcionando con el juego en pausa
	visible = false
	_construir_ui()


func _input(event: InputEvent) -> void:
	if not (event is InputEventKey and event.pressed and not event.echo):
		return
	if event.keycode != KEY_ESCAPE:
		return
	if visible:
		reanudar()
		get_viewport().set_input_as_handled()
	elif puede_pausar.call():
		pausar()
		get_viewport().set_input_as_handled()


func pausar() -> void:
	get_tree().paused = true
	visible = true
	_btn_reanudar.grab_focus()


func reanudar() -> void:
	get_tree().paused = false
	visible = false


func reiniciar_nivel() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()


func ir_al_menu_principal() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file(ESCENA_MENU_PRINCIPAL)


func _construir_ui() -> void:
	var raiz := Control.new()
	raiz.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	raiz.mouse_filter = Control.MOUSE_FILTER_STOP # que no se pueda hacer clic en lo de atras
	add_child(raiz)

	var oscuro := ColorRect.new()
	oscuro.color = Color(0, 0, 0, 0.68)
	oscuro.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	oscuro.mouse_filter = Control.MOUSE_FILTER_IGNORE
	raiz.add_child(oscuro)

	var centro := CenterContainer.new()
	centro.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	raiz.add_child(centro)

	var caja := VBoxContainer.new()
	caja.add_theme_constant_override("separation", 16)
	caja.alignment = BoxContainer.ALIGNMENT_CENTER
	centro.add_child(caja)

	caja.add_child(Estilo.crear_texto("PAUSA", 72, Color.WHITE))

	var espacio := Control.new()
	espacio.custom_minimum_size = Vector2(0, 24)
	caja.add_child(espacio)

	_btn_reanudar = Estilo.crear_boton("Reanudar")
	_btn_reanudar.pressed.connect(reanudar)
	caja.add_child(_btn_reanudar)

	var btn_reiniciar := Estilo.crear_boton("Reiniciar nivel")
	btn_reiniciar.pressed.connect(reiniciar_nivel)
	caja.add_child(btn_reiniciar)

	var btn_menu := Estilo.crear_boton("Menú principal")
	btn_menu.pressed.connect(ir_al_menu_principal)
	caja.add_child(btn_menu)
