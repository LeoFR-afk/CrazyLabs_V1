extends CanvasLayer
## Ventana emergente con los controles. Pausa el juego mientras esta abierta.

signal cerrada

const Estilo = preload("res://menu/estilo_menu.gd")

## [teclas, descripcion] -> edita esta lista para cambiar lo que se muestra
const CONTROLES := [
	[["A", "D"], "Moverse"],
	[["W", "Espacio"], "Saltar"],
	[["E"], "Interactuar"],
	[["D","A","+", "Saltar"],"Escalar (pegate a una pared)"],
	[["ESC"], "Pausa"],
]

var _panel: PanelContainer
var _teclas: Array[Control] = []
var _tiempo: float = 0.0
var _cerrando: bool = false


func _ready() -> void:
	layer = 95
	process_mode = Node.PROCESS_MODE_ALWAYS
	get_tree().paused = true
	_construir_ui()
	_animar_entrada()


func _process(delta: float) -> void:
	_tiempo += delta
	# Animacion: cada tecla brilla en onda, una despues de otra
	for i in _teclas.size():
		var k: float = 0.5 + 0.5 * sin(_tiempo * 4.0 - i * 0.8)
		_teclas[i].modulate = Color.WHITE.lerp(Color(0.5, 1.0, 1.0), k)


func _input(event: InputEvent) -> void:
	if _cerrando:
		return
	if event is InputEventKey and event.pressed and not event.echo:
		if event.physical_keycode in [KEY_E, KEY_ENTER, KEY_KP_ENTER, KEY_SPACE] \
				or event.keycode == KEY_ESCAPE:
			get_viewport().set_input_as_handled()
			_cerrar()


func _construir_ui() -> void:
	var raiz := Control.new()
	raiz.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(raiz)

	var oscuro := ColorRect.new()
	oscuro.color = Color(0, 0, 0, 0.6)
	oscuro.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	raiz.add_child(oscuro)

	var centro := CenterContainer.new()
	centro.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	raiz.add_child(centro)

	_panel = PanelContainer.new()
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = Color(0.04, 0.09, 0.12, 0.96)
	estilo.border_color = Estilo.COLOR_BORDE
	estilo.set_border_width_all(3)
	estilo.set_corner_radius_all(10)
	estilo.set_content_margin_all(36)
	_panel.add_theme_stylebox_override("panel", estilo)
	centro.add_child(_panel)

	var caja := VBoxContainer.new()
	caja.add_theme_constant_override("separation", 18)
	_panel.add_child(caja)

	var titulo := Estilo.crear_texto("CONTROLES", 56, Color(1.0, 1.0, 1.0, 1.0))  # color del texto
	caja.add_child(titulo)

	var rejilla := GridContainer.new()
	rejilla.columns = 2
	rejilla.add_theme_constant_override("h_separation", 30)
	rejilla.add_theme_constant_override("v_separation", 14)
	caja.add_child(rejilla)

	for fila in CONTROLES:
		var izq := HBoxContainer.new()
		izq.custom_minimum_size = Vector2(250, 0)
		izq.alignment = BoxContainer.ALIGNMENT_END
		izq.add_theme_constant_override("separation", 8)
		for t: String in fila[0]:
			var tecla := _crear_tecla(t)
			_teclas.append(tecla)
			izq.add_child(tecla)
		rejilla.add_child(izq)

		var desc := Estilo.crear_texto(fila[1], 28, Color.WHITE)
		desc.add_theme_constant_override("outline_size", 2)   
		desc.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
		desc.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		rejilla.add_child(desc)

	var boton := Estilo.crear_boton("Entendido  [E]")
	boton.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	boton.pressed.connect(_cerrar)
	caja.add_child(boton)
	boton.grab_focus()


func _crear_tecla(texto: String) -> Control:
	var p := PanelContainer.new()
	var s := StyleBoxFlat.new()
	s.bg_color = Color(0.1, 0.2, 0.26)
	s.border_color = Estilo.COLOR_BORDE
	s.set_border_width_all(2)
	s.border_width_bottom = 5 # efecto de tecla
	s.set_corner_radius_all(6)
	s.content_margin_left = 14
	s.content_margin_right = 14
	s.content_margin_top = 6
	s.content_margin_bottom = 4
	p.add_theme_stylebox_override("panel", s)
	p.custom_minimum_size = Vector2(52, 0)
	var l := Estilo.crear_texto(texto, 26, Color.WHITE)
	l.add_theme_constant_override("outline_size", 0)
	p.add_child(l)
	return p


func _animar_entrada() -> void:
	_panel.modulate.a = 0.0
	await get_tree().process_frame # espera a que el panel tenga su tamano
	_panel.pivot_offset = _panel.size / 2.0
	_panel.scale = Vector2(0.6, 0.6)
	var t := create_tween().set_parallel(true)
	t.tween_property(_panel, "scale", Vector2.ONE, 0.35) \
			.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	t.tween_property(_panel, "modulate:a", 1.0, 0.25)


func _cerrar() -> void:
	if _cerrando:
		return
	_cerrando = true
	var t := create_tween().set_parallel(true)
	t.tween_property(_panel, "scale", Vector2(0.8, 0.8), 0.2).set_ease(Tween.EASE_IN)
	t.tween_property(_panel, "modulate:a", 0.0, 0.2)
	await t.finished
	get_tree().paused = false
	cerrada.emit()
	queue_free()
