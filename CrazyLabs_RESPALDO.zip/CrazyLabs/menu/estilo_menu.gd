extends RefCounted
## Estilo compartido de los menus (principal y pausa): tema neon cian, como el resto del juego.

const COLOR_TEXTO := Color(1.0, 1.0, 1.0, 1.0)
const COLOR_BORDE := Color(0.344, 0.351, 0.578, 0.92)


static func crear_boton(texto: String) -> Button:
	var b := Button.new()
	b.text = texto
	b.custom_minimum_size = Vector2(340, 58)
	b.focus_mode = Control.FOCUS_ALL
	b.add_theme_font_size_override("font_size", 26)
	b.add_theme_color_override("font_color", COLOR_TEXTO)
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_color_override("font_focus_color", Color.WHITE)
	b.add_theme_color_override("font_pressed_color", Color.WHITE)
	b.add_theme_stylebox_override("normal", _caja(Color(0.344, 0.351, 0.578, 0.92), 2))
	b.add_theme_stylebox_override("hover", _caja(Color(0.344, 0.351, 0.578, 0.92), 2))
	b.add_theme_stylebox_override("focus", _caja(Color(0.344, 0.351, 0.578, 0.92), 2))
	b.add_theme_stylebox_override("pressed", _caja(Color(0.344, 0.351, 0.578, 0.92), 2))
	return b


static func crear_texto(texto: String, tam: int, color: Color = COLOR_TEXTO) -> Label:
	var l := Label.new()
	l.text = texto
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_font_size_override("font_size", tam)
	l.add_theme_color_override("font_color", color)
	l.add_theme_constant_override("outline_size", 8)
	l.add_theme_color_override("font_outline_color", Color.WHITE)
	return l


static func _caja(fondo: Color, borde: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = fondo
	s.border_color = COLOR_BORDE
	s.set_border_width_all(borde)
	s.set_corner_radius_all(6)
	return s
